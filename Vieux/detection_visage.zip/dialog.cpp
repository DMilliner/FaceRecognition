#include "dialog.h"
#include "ui_dialog.h"

#include <QTimer>
#include <QFileDialog>
#include <stdio.h>
#include <stdlib.h>
#include <QMessageBox>
#include <QInputDialog>
#include <QTextStream>


// Remerciements à Arthur pour son code qui m'a permis de comprendre bien des choses sur Qt
// Version 0.3

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    //Configure la fenetre
    ui->setupUi(this);

    // Récupère les dimensions du label pour redimensionner les images
    // A la taille du lable (Pratique pour les avi de taille variable)
    QRect cadre = ui->label->geometry();
    cadre.getRect(&x,&y,&w,&h);

    // Définition d'un background
    Mat background;
    background = imread("./Menu/poker_face.jpg");
    cv::resize(background,background,Size(w,h),0,0,INTER_LINEAR);
    QImage Qbackground = convert_Mat(background);
    ui->label->setPixmap(QPixmap::fromImage(Qbackground));

    video = NULL;

    // Definit le nom de la fenetre
    this->setWindowTitle("Face Detection");

    // Chemin de la cascade et de la database
    face_cascade_name = "./haarcascade_frontalface_alt.xml";
    profil_cascade_name = "./haarcascade_profileface.xml";
    databaseName = "./Database.txt";
    databaseofName = "./NameDatabase.txt";

    // Récupère les données de la database
    try
    {
      read_csv(databaseName,databaseofName, images, labels, ';');
    }
    catch (cv::Exception& e)
    {
      //cerr << "Error opening file \"" << databaseName << "\". Reason: " << e.msg << endl;
      exit(1);
    }

    // Crée un model de base de visages et l'entraine
    model = createFisherFaceRecognizer();
    model->train(images, labels);


    // Esssae de lire la cascade
    if( !face_cascade.load( face_cascade_name ) || !profil_cascade.load(profil_cascade_name))
    {
        exit(-1);
    }


    // Crée le timer
    temporisation = new QTimer(this);

    // Active le bouton browser pour récupérer les vidéos
    connect(ui->bouton_browser,SIGNAL(clicked()),this,SLOT(on_bouton_browser_clicked()));
    connect(ui->bouton_add,SIGNAL(clicked()),this,SLOT(on_bouton_add_clicked()));
    connect(ui->bouton_run, SIGNAL(released()), this, SLOT(runtimmer())); //Active le timer quand on appuie sur le bouton run
    connect(temporisation, SIGNAL(timeout()), this, SLOT(traitement())); // A chaque fin de timer on traite une image. Remplace la boucle for(;;) qui ne marche pas

    // Par défaut c'est la caméra qui est activé
    video = cvCaptureFromCAM( 0 );

    if(video)
    {
        ui->bouton_run->setText("Run camera");
        flip_cam = true; //Utile pour avoir l'image de la caméra dans le bon sens
    }

}
void Dialog::runtimmer()
{
    temporisation->start(20); // Lance le timer
}

void Dialog::on_bouton_pause_clicked()
{
    if(ui->bouton_pause->text() == "Quit")
            this->close();

        if(temporisation->isActive() == true)
        {
            temporisation->stop(); //Stop le timer et donc le traitement
            ui->bouton_pause->setText("Unpause");
        }
        else
        {
            temporisation->start(20); //Reactive le timer
            ui->bouton_pause->setText("Pause");
        }
}

void Dialog::on_bouton_browser_clicked()
{
    // On libere le precedent flux si il y en a un (Beug : Rame tout de meme après deux trois vidéos ouvertes à la suite)
    cvReleaseCapture( &video );

    // On lance le navigateur de fichier pour récupérer l'avi (Beug : il se lance 2 fois)
    QString fichier = QFileDialog::getOpenFileName(0, "Ouvrir un fichier", QString(), "Avi (*.avi)");

    std::string avi_name;
    avi_name = fichier.toStdString(); // Convertit un Qstring en std::string
    video = cvCaptureFromAVI( avi_name.c_str() ); // Convertir un std::string en char*

    if(video)
    {
        flip_cam = false;
        ui->plainTextEdit->appendPlainText(fichier); //Affiche le chemin du fichier dans la barre
        ui->bouton_run->setText("Run Avi");
        ui->bouton_pause->setText("Pause"); //Utile pour un beug rencontré

        // Affiche la preview de la video
        Mat preview;
        preview = cvQueryFrame(video);
        cv::resize(preview,preview,Size(w,h),0,0,INTER_LINEAR);
        QImage Qpreview = convert_Mat(preview);
        ui->label->setPixmap(QPixmap::fromImage(Qpreview));

     }
}

void Dialog::on_bouton_add_clicked()
{
    if(frame.empty())
        return;
    else

    temporisation->stop();

    std::vector<Rect> faces;
    Mat frame_gray;
    Mat face_resized;
    QImage face_saved;


    if(flip_cam == true)
        cv::flip(frame,frame,1);

    cvtColor( frame, frame_gray, CV_BGR2GRAY );
    equalizeHist( frame_gray, frame_gray );

    face_cascade.detectMultiScale( frame_gray, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30, 30));

    if(faces.size() != 0)
    {
        QMessageBox::information(this, "Visage(s) trouve(s)", "Visage(s) trouve(s)");

        for( vector<Rect>::const_iterator r = faces.begin(); r != faces.end(); r++)
        {
            Mat face(frame,*r);
            cv::resize(face, face_resized, Size(160, 160), 1.0, 1.0, INTER_CUBIC);
            cv::imshow("Visage",face_resized);
            face_saved = convert_Mat(face_resized);
            QString fichier = QFileDialog::getSaveFileName(0, "Sauvegarder l'image", QString(), "PNG (*.png)");
            face_saved.save(fichier);

            QFile file("./Test.txt");
            file.open(QIODevice::WriteOnly | QIODevice::Append);
            QTextStream flux(&file);
            flux.setCodec("UTF-8");
            flux << fichier << endl;
            file.close();

            cv::destroyWindow("Visage");
        }
    temporisation->start(20);
    }
    else
         QMessageBox::information(this, "Erreur", "Aucun visages trouvés");
    temporisation->start(20);

}

void Dialog::traitement()
{
    connect(ui->bouton_pause,SIGNAL(clicked()),this,SLOT(on_bouton_pause_clicked())); //Active le bouton pause lors du traitement


    frame = cvQueryFrame( video ); //Recupère l'image

    if( frame.empty() ) // On se trouve a la fin de la vidéo
    {
            cvReleaseCapture( &video );
            temporisation->stop();
            ui->bouton_pause->setText("Quit");
            ui->bouton_run->setText("Finish");
    }
    else // Sinon on continue
    {
        detection(frame,flip_cam);
        ui->bouton_run->setText("Running");
    }

}

void Dialog::detection(Mat& frame, bool flip_cam)
{
    int i=0,j=0;
    std::vector<Rect> faces;
    std::vector<Rect> profils;
    Mat frame_gray;
    Mat face_resized;
    int prediction;
    double accuracy=0;
    string name;

    frame.copyTo(frame_worked);

    if(flip_cam == true)
        cv::flip(frame_worked,frame_worked,1);

    cvtColor( frame_worked, frame_gray, CV_BGR2GRAY );
    equalizeHist( frame_gray, frame_gray );

    face_cascade.detectMultiScale( frame_gray, faces, 2, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30, 30));
    profil_cascade.detectMultiScale( frame_gray, profils, 2, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30, 30));

    for( vector<Rect>::const_iterator r = faces.begin(); r != faces.end(); r++, i++ )
    {
        Mat face(frame,*r);
        cv::resize(face, face_resized, Size(160, 160), 1.0, 1.0, INTER_CUBIC);
        cvtColor( face_resized, face_resized, CV_BGR2GRAY ); // On doit placer le visage détecté à la meme taille que les images de la base de données
        model->predict(face_resized,prediction,accuracy);

       //Point center( faces[i].x + faces[i].width/2, faces[i].y + faces[i].height/2 );
       Point corner(faces[i].x + faces[i].width, faces[i].y);
       cv::rectangle(frame_worked,*r,Scalar(255,255,255),1,8,0);
       //ellipse( frame_worked, center, Size( faces[i].width/2, faces[i].height/2), 0, 0, 360, Scalar( 255, 0, 255 ), 2, 8, 0 );
       putText( frame_worked, base_name[prediction], corner ,100, 1, Scalar( 255, 255, 255 ), 1, 8, 0);
    }

    for( vector<Rect>::const_iterator l = profils.begin(); l != profils.end(); l++, j++ )
    {
        cv::rectangle(frame_worked,*l,Scalar(255,255,255),1,8,0);
    }


    cv::resize(frame_worked,frame_worked,Size(w,h),0,0,INTER_LINEAR);
    QImage qframe = convert_Mat(frame_worked); // On convertit l'image en Qimage pour qu'elle soit affiché
    ui->label->setPixmap(QPixmap::fromImage(qframe));

}

QImage Dialog::convert_Mat(Mat& frame)
{
    QImage frame_convert((uchar*)frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
    frame_convert = frame_convert.rgbSwapped();
    return frame_convert;
}

void Dialog::read_csv(const string& filename,const string& dataname, vector<Mat>& images, vector<int>& labels, char separator)
{
    string line;

    ///////// Ouverture du fichier database
    std::ifstream file(filename.c_str(), ifstream::in);
    if (!file)
    {
        string error_message = "No valid input file was given, please check the given filename.";
        CV_Error(CV_StsBadArg, error_message);
    }

    ///////// Remplis les vecteurs à partir des lignes
    string path, classlabel;
    while (getline(file, line))
    {
        stringstream liness(line);
        getline(liness, path, separator);
        getline(liness, classlabel);
        if(!path.empty() && !classlabel.empty())
        {
            images.push_back(imread(path,0));
            //cv::imshow("test",imread(path,0));
            labels.push_back(atoi(classlabel.c_str()));
        }
    }

    ////// Ouverture du fichier database_name
    std::ifstream file_name(dataname.c_str(), ifstream::in);
    if (!file_name)
    {
        string error_message = "No valid input file was given, please check the given filename.";
        CV_Error(CV_StsBadArg, error_message);
    }

    /////////// Remplis la map à partir des lignes
    string name, id;
    while (getline(file_name, line))
    {
        stringstream liness(line);
        getline(liness, name, separator);
        getline(liness, id);
        if(!id.empty() && !name.empty())
            base_name[atoi(id.c_str())]=name;
    }

}

////////////////////////////////////////////////////////////////////////////////////////////////


Dialog::~Dialog()
{
    delete ui;
}

void Dialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}
