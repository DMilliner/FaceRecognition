#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QImage>

#include <iostream>
#include <iterator>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <map>

// pour openCV
#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/video/tracking.hpp"
#include "opencv2/contrib/contrib.hpp"

using namespace cv;
using namespace std;

namespace Ui {
    class Dialog;
}

class Dialog : public QDialog {
    Q_OBJECT
public:
    Dialog(QWidget *parent = 0);
    ~Dialog();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::Dialog *ui;

    // Variables utiles
    int x,y,w,h;
    bool flip_cam;

    // Flux vidéo
    CvCapture* video;

    // Les Chaines de caractères
    String face_cascade_name;
    String profil_cascade_name;
    String databaseName;
    String databaseofName;
    QString file_name;

    // Cascade et la matrice à traiter
    CascadeClassifier face_cascade;
    CascadeClassifier profil_cascade;
    Mat frame;
    Mat frame_worked;

    //Pour entrainer la database
    vector<Mat> images;
    vector<int> labels;
    // Le modele de la database
    Ptr<FaceRecognizer> model;
    map<int,string> base_name;
    // Le timer
    QTimer* temporisation;

    // Les fonctions
    void detection(Mat &frame, bool flip_cam);
    QImage convert_Mat(Mat& frame);
    void read_csv(const string& filename,const string& dataname, vector<Mat>& images, vector<int>& labels, char separator);


public slots:
    void traitement();
    void runtimmer();

private slots:
    void on_bouton_pause_clicked();
    void on_bouton_browser_clicked();
    void on_bouton_add_clicked();
};

#endif // DIALOG_H
