/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created: Thu Feb 21 18:52:24 2013
**      by: Qt User Interface Compiler version 4.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QPushButton *bouton_pause;
    QPushButton *bouton_run;
    QPushButton *bouton_browser;
    QPlainTextEdit *plainTextEdit;
    QLabel *label;
    QPushButton *bouton_add;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->setEnabled(true);
        Dialog->resize(609, 460);
        Dialog->setMaximumSize(QSize(609, 460));
        Dialog->setAutoFillBackground(true);
        Dialog->setSizeGripEnabled(false);
        bouton_pause = new QPushButton(Dialog);
        bouton_pause->setObjectName(QString::fromUtf8("bouton_pause"));
        bouton_pause->setGeometry(QRect(420, 400, 106, 31));
        bouton_run = new QPushButton(Dialog);
        bouton_run->setObjectName(QString::fromUtf8("bouton_run"));
        bouton_run->setGeometry(QRect(300, 400, 111, 31));
        bouton_browser = new QPushButton(Dialog);
        bouton_browser->setObjectName(QString::fromUtf8("bouton_browser"));
        bouton_browser->setGeometry(QRect(240, 400, 51, 31));
        plainTextEdit = new QPlainTextEdit(Dialog);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(20, 400, 211, 31));
        label = new QLabel(Dialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 30, 551, 341));
        bouton_add = new QPushButton(Dialog);
        bouton_add->setObjectName(QString::fromUtf8("bouton_add"));
        bouton_add->setGeometry(QRect(540, 400, 41, 31));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", 0, QApplication::UnicodeUTF8));
        bouton_pause->setText(QApplication::translate("Dialog", "Pause", 0, QApplication::UnicodeUTF8));
        bouton_run->setText(QApplication::translate("Dialog", "Run", 0, QApplication::UnicodeUTF8));
        bouton_browser->setText(QApplication::translate("Dialog", "...", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        bouton_add->setText(QApplication::translate("Dialog", "+", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
