#ifndef STATISTIQUE_H
#define STATISTIQUE_H

#include <QDialog>
#include "facedetection.h"

namespace Ui {
class statistique;
}

class statistique : public QDialog
{
    Q_OBJECT
    
public:
    explicit statistique(QWidget *parent = 0);
    ~statistique();
    
private:
    Ui::statistique *ui;
};

#endif // STATISTIQUE_H
