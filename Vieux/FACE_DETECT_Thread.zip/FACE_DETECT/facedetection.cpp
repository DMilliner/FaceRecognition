#include "facedetection.h"
#include <QImage>

Facedetection::Facedetection()
{
    // On initialise toutes les variables qui ne changeront pas
    // On en profite pour entrainer le model qui va nous servir à devenir les noms

    // On charge la cascade qui va nous servir à détecter les visages
    if(!haar_cascade.load("haarcascade_frontalface_alt.xml"))
        exit(-1);
    if(!haar_cascade_profil.load("haarcascade_profileface.xml"))
        exit(-1);

    // On créer le FaceRecognizer
    model = cv::createFisherFaceRecognizer();
    update_facerecognizer();

    im_width = 160;
    im_height = 160;

    // On lance par défaut la caméra au démarage
    video = cvCaptureFromCAM( 0 );
    flip_cam = true;

}

void Facedetection::update_facerecognizer()
{
    // Ouverture des Basse de Données contenant les noms et les visages
    try {
        read_csv("Database.txt","DatabaseName.txt",faceimages,facelabels,';');
    } catch (cv::Exception& e) {
        std::cout << "Error opening file \"" << "database.txt" << "\". Reason: " << e.msg << std::endl;
    exit(-1);
    }
    model->train(faceimages, facelabels);
}



void Facedetection::run()
{
    // On récupère une première image pour rentrer dans la boucle
    frame = cvQueryFrame(video);

    while(!frame.empty()) // On continue tant que l'on est pas arriver à la fin de la vidéo
    {
        traite_image(frame,flip_cam); // On détecte les visages et on gère l'aspect graphique
        frame = cvQueryFrame( video ); // Quand on arrive à la fin de la vidéo la matrice récupérée est vide
        msleep(10);
    }
    //cvReleaseCapture(&video); // On libère le flux vidéo et le thread se termine
     video = cvCaptureFromCAM( 0 );
     set_flip_cam(true);
}

void Facedetection::traite_image(Mat& frame,bool flip_cam)
{
    Mat gray;
    int prediction,i=0;
    double confidence=0;

    if(flip_cam == true)
        flip(frame,frame,1); // Evite l'effet miroir avec une caméra

    // On convertit en gris et on égalise l'histogramme
    cvtColor(frame, gray, CV_BGR2GRAY);
    equalizeHist( gray, gray);

    haar_cascade.detectMultiScale(gray, facedetected,2.0);
    haar_cascade_profil.detectMultiScale(gray,profildetected,2.0);

    for( vector<Rect>::const_iterator r = facedetected.begin(); r != facedetected.end(); r++,i++)
    {

        Mat face(frame,*r); // On récupère l'image du visage

        cv::resize(face, face, cv::Size(im_width, im_height), 1.0, 1.0, cv::INTER_CUBIC);
        cvtColor( face, face, CV_BGR2GRAY ); // On la redimensionne et on la convertit en gris

        model->predict(face,prediction,confidence); // On devine l'id d'un nom inclus dans notre Base de données
        //cout << confidence << endl;

        rectangle(frame, *r, CV_RGB(255, 255,255), 1);
        cv::Point corner(facedetected[i].x , facedetected[i].y);
        cv::putText(frame, base_name[prediction], corner, cv::FONT_HERSHEY_PLAIN, 1.0, CV_RGB(255,255,255), 1); // On affiche le rectangle et le nom autour du visage

    }

    /*for( vector<Rect>::const_iterator l = profildetected.begin(); l != profildetected.end(); l++)
        rectangle(frame,*l,CV_RGB(255,255,255),1);*/

    cv::resize(frame,frame,Size(width_screen,height_screen),0,0,INTER_LINEAR); // On redimensionne l'image à la taille du cadre d'affichage (Utile pour des avi de taille différente)
    emit envoimage(mat2qimage(frame)); // On envoie ce signal à un slot qui va se charger d'afficher l'image
}


QImage Facedetection::mat2qimage(Mat& frame)
{
    // Seul une Qimage peut etre afficher dans la fenetre du programme
    // On convertit donc la Mat en QImage
    QImage frame_convert((uchar*)frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
    frame_convert = frame_convert.rgbSwapped();
    return frame_convert;
}

void Facedetection::read_csv(const string& filename,const string& dataname, vector<Mat>& images, vector<int>& labels, char separator)
{
    string line;

    ///////// Ouverture du fichier database
    std::ifstream file(filename.c_str(), ifstream::in);
    if (!file)
    {
        string error_message = "No valid input file was given, please check the given filename.";
        CV_Error(CV_StsBadArg, error_message);
    }

    ///////// Remplis les vecteurs à partir des lignes
    string path, classlabel;
    while (getline(file, line))
    {
        stringstream liness(line);
        getline(liness, path, separator);
        getline(liness, classlabel);
        if(!path.empty() && !classlabel.empty())
        {
            images.push_back(imread(path,0));
            //cv::imshow("test",imread(path,0));
            labels.push_back(atoi(classlabel.c_str()));
        }
    }

    ////// Ouverture du fichier database_name
    std::ifstream file_name(dataname.c_str(), ifstream::in);
    if (!file_name)
    {
        string error_message = "No valid input file was given, please check the given filename.";
        CV_Error(CV_StsBadArg, error_message);
    }

    /////////// Remplis la map à partir des lignes
    string name, id;
    while (getline(file_name, line))
    {
        stringstream liness(line);
        getline(liness, name, separator);
        getline(liness, id);
        if(!id.empty() && !name.empty())
            base_name[atoi(id.c_str())]=name;
    }

}

void Facedetection::test()
{

}
