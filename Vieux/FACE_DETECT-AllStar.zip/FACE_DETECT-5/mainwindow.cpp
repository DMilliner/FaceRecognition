#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "add_visage.h"


#include "QMessageBox"
#include "statistique.h"

MainWindow::MainWindow(QWidget *parent,Facedetection *facedetect) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Récupère les dimensions du cadre d'affichage des images
    QRect cadre = ui->label->geometry();
    cadre.getRect(&x,&y,&width_screen,&heigth_screen);

    facedetection=facedetect;
    facedetection->set_dim_screen(width_screen,heigth_screen);// Met à jour les dimensions du cadre dans facedetection

    // Création d'une image de présentation
    Mat background;
    background = imread("./Menu/BW.jpg");
    cv::resize(background,background,Size(width_screen,heigth_screen),0,0,INTER_LINEAR);
    QImage Qbackground = facedetection->mat2qimage(background);
    ui->label->setPixmap(QPixmap::fromImage(Qbackground));

    // On connecte les signaux à leurs fonctions
    connect(facedetection,SIGNAL(envoimage(QImage)),this,SLOT(updateimage(QImage)));
    connect(ui->buttonRun,SIGNAL(clicked()),facedetection,SLOT(start()));

    connect(ui->buttonAdd,SIGNAL(clicked()),this,SLOT(addminiature()));
    connect(ui->buttonBrowser,SIGNAL(clicked()),this,SLOT(on_bouton_browser_cliked()));
    connect(ui->buttonPause,SIGNAL(clicked()),this,SLOT(pause_thread()));
    connect(facedetection,SIGNAL(display_windowStat()),this,SLOT(statistique_display()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::pause_thread()
{
    facedetection->detect->terminate();
    facedetection->terminate();
}

void MainWindow::updateimage(QImage image)
{
    ui->label->setPixmap(QPixmap::fromImage(image));
}

void MainWindow::statistique_display()
{
    //facedetection->terminate();
    statistique *window_stat = new statistique();
    window_stat->set_stats(facedetection->Stat);
    window_stat->exec();
}


void MainWindow::addminiature()
{       
    //Quelques beugs à régler
    int i=0;
    Mat frame;
    vector<Rect> faces_added;
    vector<Point> faces_tracked;

    //facedetection->terminate();

    frame = facedetection->get_MatImage();
    faces_added= facedetection->detect->get_FacesDetected();
    //faces_tracked= facedetection->get_minPoint();

    add_visage *Qaddbox = new add_visage();

    if(faces_added.size() != 0)
    {
            QMessageBox::information(this, "Visage(s) trouve(s)", "Visage(s) trouve(s)");

            for( vector<Rect>::const_iterator r = faces_added.begin(); r != faces_added.end(); r++)
            {
                Mat face(frame,*r);
                cv::resize(face, face, cv::Size(160, 160), 1.0, 1.0, cv::INTER_CUBIC);
                QImage Qface = facedetection->mat2qimage(face);

                Qaddbox->setImage(Qface);
                Qaddbox->exec();

            }
            facedetection->detect->update_facerecognizer();
            //facedetection->start();
    }
    else if(faces_tracked.size() != 0 && faces_added.size()==0)
    {
        QMessageBox::information(this, "Visage(s) trouve(s)", "Visage(s) trouve(s)");

        vector<Size> faces_size;
        //faces_size=facedetection->get_FaceWindowSize();

        for( vector<Point>::const_iterator s = faces_tracked.begin(); s != faces_tracked.end(); s++,i++)
        {
            Point Nul = *s;
            if(faces_size.size() !=0 && Nul.x !=0)
            {
            Point min = *s;
            Size calc(faces_size[i].width,y+faces_size[i].height);
            Point max(min.x+calc.width,min.y+calc.height);
            Rect temp(min,max);
            Mat face_bis(frame,temp);

            cv::resize(face_bis, face_bis, cv::Size(160, 160), 1.0, 1.0, cv::INTER_CUBIC);
            QImage Qface_bis = facedetection->mat2qimage(face_bis);

            Qaddbox->setImage(Qface_bis);
            Qaddbox->exec();
            }
        }
        facedetection->detect->update_facerecognizer();
        //facedetection->start();
    }
    else
        QMessageBox::information(this, "Erreur", "Aucun visages trouves");
    //if(!frame.empty())
        //facedetection->start();
}

void MainWindow::on_bouton_browser_cliked()
{

    // Détruis le thread en cours si il y en a un
    //facedetection->detect->terminate();
    //facedetection->terminate();

    // On libere le precedent flux si il y en a un
    cvReleaseCapture( &facedetection->video);

    // On lance le navigateur de fichier pour récupérer l'avi
    ui->textBrowser->clear();
    QString fichier = QFileDialog::getOpenFileName(0, "Ouvrir un fichier", QString(), "Avi (*.avi)");
    ui->textBrowser->setText(fichier);

    std::string avi_name;
    avi_name = fichier.toStdString(); // Convertit un Qstring en std::string
    facedetection->video = cvCaptureFromAVI( avi_name.c_str() ); // Convertit un std::string en char

    if(fichier.contains("Test"))
    {
        QString name_test;
        facedetection->set_display_screen(true);

        string path;
        path = fichier.toStdString();
        unsigned taille = path.find_last_of("/");
        path.substr(0, taille);
        path.substr(taille+1);
        QString temp(path.substr(taille+1).c_str());

       string name = temp.toStdString();
       unsigned size = name.find("_");

       QString nametoSave(name.substr(0,size).c_str());


       facedetection->set_nameToTest(nametoSave.toStdString());

    }

    // Une preview de la vidéo
    if(facedetection->video)
    {
        if(fichier.contains("Test"))
        facedetection->set_flip_cam(false);

        // Affiche la preview de la video
        Mat preview;
        preview = cvQueryFrame(facedetection->video);
        cv::resize(preview,preview,Size(width_screen,heigth_screen),0,0,INTER_LINEAR);

        updateimage(facedetection->mat2qimage(preview));
    }else
        {
            facedetection->video = cvCaptureFromCAM( 0 );
            facedetection->set_flip_cam(true);
        }
}
