#include "facetracking.h"

facetracking::facetracking(float cadrex,float cadrey,string name)
{
    this->cadrex=cadrex;
    this->cadrey=cadrey;
    this->name=name;
}

void facetracking::run()
{

}
