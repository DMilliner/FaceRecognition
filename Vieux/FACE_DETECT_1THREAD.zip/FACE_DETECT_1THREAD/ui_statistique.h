/********************************************************************************
** Form generated from reading UI file 'statistique.ui'
**
** Created: Fri May 24 14:52:06 2013
**      by: Qt User Interface Compiler version 4.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUE_H
#define UI_STATISTIQUE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QProgressBar>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_statistique
{
public:
    QLabel *label_3;
    QLineEdit *lineEdit_7;
    QLabel *label_5;
    QLineEdit *lineEdit_5;
    QProgressBar *progressBar;
    QLabel *label_2;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_6;
    QLabel *label;
    QLabel *label_6;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_2;
    QLabel *label_7;
    QLabel *label_4;
    QPlainTextEdit *plainTextEdit;
    QLabel *label_8;
    QLineEdit *lineEdit;
    QPushButton *pushButton;

    void setupUi(QDialog *statistique)
    {
        if (statistique->objectName().isEmpty())
            statistique->setObjectName(QString::fromUtf8("statistique"));
        statistique->resize(441, 485);
        label_3 = new QLabel(statistique);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(70, 300, 111, 21));
        lineEdit_7 = new QLineEdit(statistique);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(250, 370, 113, 25));
        label_5 = new QLabel(statistique);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(70, 170, 161, 21));
        lineEdit_5 = new QLineEdit(statistique);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(250, 290, 113, 25));
        progressBar = new QProgressBar(statistique);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(250, 170, 111, 21));
        progressBar->setValue(24);
        label_2 = new QLabel(statistique);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(70, 250, 111, 21));
        lineEdit_4 = new QLineEdit(statistique);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(250, 240, 113, 25));
        lineEdit_6 = new QLineEdit(statistique);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(250, 320, 113, 25));
        label = new QLabel(statistique);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 220, 111, 21));
        label_6 = new QLabel(statistique);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(70, 140, 161, 21));
        lineEdit_3 = new QLineEdit(statistique);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(250, 210, 113, 25));
        lineEdit_2 = new QLineEdit(statistique);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(250, 140, 113, 25));
        label_7 = new QLabel(statistique);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(70, 110, 171, 21));
        label_4 = new QLabel(statistique);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(70, 330, 111, 21));
        plainTextEdit = new QPlainTextEdit(statistique);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(120, 40, 211, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Abyssinica SIL"));
        font.setPointSize(20);
        plainTextEdit->setFont(font);
        label_8 = new QLabel(statistique);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(70, 380, 161, 21));
        lineEdit = new QLineEdit(statistique);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(250, 110, 113, 25));
        pushButton = new QPushButton(statistique);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(270, 420, 87, 27));

        retranslateUi(statistique);

        QMetaObject::connectSlotsByName(statistique);
    } // setupUi

    void retranslateUi(QDialog *statistique)
    {
        statistique->setWindowTitle(QApplication::translate("statistique", "Dialog", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("statistique", "Vrais n\303\251gatifs", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("statistique", "Taux de reconnaissance", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("statistique", "Faux positifs", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("statistique", "Vrais positifs", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("statistique", "Nombre de frames", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("statistique", "Nombre de reconnaissance", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("statistique", "Faux n\303\251gatifs", 0, QApplication::UnicodeUTF8));
        plainTextEdit->setPlainText(QApplication::translate("statistique", " STATISTIQUES", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("statistique", "Temps de traitement", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("statistique", "OK", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class statistique: public Ui_statistique {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUE_H
