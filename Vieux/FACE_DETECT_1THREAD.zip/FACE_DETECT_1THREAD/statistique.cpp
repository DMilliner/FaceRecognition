#include "statistique.h"
#include "ui_statistique.h"

statistique::statistique(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::statistique)
{
    ui->setupUi(this);
}

statistique::~statistique()
{
    delete ui;
}

void statistique::set_stats(Values_Statistique stats)
{
    QString info_1,info_2,info_3,info_4,info_5,info_6,info_7;

    info_1.sprintf("%f",stats.NbFrame);
    info_2.sprintf("%f",stats.NbReconnaissance);
    info_3.sprintf("%f",stats.TempsTraitement);

    int taux = stats.TauxDeReconnaissance;

    ui->lineEdit->setText(info_2);
    ui->lineEdit_2->setText(info_1);
    ui->progressBar->setValue(taux);

    /*ui->lineEdit_4->setText();
    ui->lineEdit_5->setText();
    ui->lineEdit_6->setText();
    ui->lineEdit_7->setText();*/
}
