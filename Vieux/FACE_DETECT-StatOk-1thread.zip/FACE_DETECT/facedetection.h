#ifndef FACEDETECTION_H
#define FACEDETECTION_H

#include <QThread>
#include <QObject>
#include <QImage>
#include <QDialog>

#include <iostream>
#include <iterator>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <map>

// pour openCV
#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/video/tracking.hpp"
#include "opencv2/contrib/contrib.hpp"

#include "statistique.h"

using namespace cv;
using namespace std;

struct Face
{

    Size windowsize;
    string name;
    Point prevLoc;
    Mat img;
    bool trackingup;
    Point minLoc;
    Point maxLoc;
    Point matchLoc;

};

struct Values_Statistique
{
    float NbFrame;
    float NbDetection;
    double TauxDeDetection;

    double NbReconnaissanceOkIdOK;
    double NbReconnaissanceOkIdKo;
    double NbReconnaissanceKoIdInconnu;
    double NbReconnaissanceKoIdConnu;
    double TauxDeReconnaissance;

    double TempsTraitement;
};

class Facedetection : public QThread
{
    Q_OBJECT

public:
    Facedetection();
    CvCapture* video;

    void run();
    void traite_image(Mat& frame,bool flip_cam);

    inline void set_dim_screen(int w, int h){width_screen=w;height_screen=h;}
    inline void set_flip_cam(bool option){flip_cam=option;}
    inline void set_display_screen(bool option){display_stat=option;}
    inline Mat get_MatImage(void){return frame;}
    inline vector<Rect> get_FacesDetected(void){return facedetected;}
    inline void set_nameToTest(string name){NomInVideoTest=name;}
    bool check_nameinDB(string name);


    QImage mat2qimage(Mat &mat);
    void read_csv(const string& filename,const string& dataname, vector<Mat>& images, vector<int>& labels, char separator);
    void update_facerecognizer();

    cv::CascadeClassifier haar_cascade;
    cv::CascadeClassifier haar_cascade_profil;

    Ptr<cv::FaceRecognizer> model;
    vector<cv::Mat> faceimages;
    vector<int> facelabels;

    Mat frame,img,templ,result;
    vector<Rect> facedetected;
    vector<Rect> profildetected;
    bool flip_cam;
    bool display_stat;
    map<int,string> base_name;

    int width_screen,height_screen;

    int im_width,im_height;
    string NomInVideoTest;

    int result_cols,result_rows;
    double minVal,maxVal;

    struct Face nouveau;
    vector<Face> facetracked;

    struct Values_Statistique Stat;

signals:
    void envoimage(QImage image);
    void display_windowStat();
};

#endif // FACEDETECTION_H
