/****************************************************************************
** Meta object code from reading C++ file 'facedetection.h'
**
** Created: Mon May 27 16:30:17 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "facedetection.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'facedetection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Facedetection[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      21,   15,   14,   14, 0x05,
      39,   14,   14,   14, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_Facedetection[] = {
    "Facedetection\0\0image\0envoimage(QImage)\0"
    "display_windowStat()\0"
};

void Facedetection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Facedetection *_t = static_cast<Facedetection *>(_o);
        switch (_id) {
        case 0: _t->envoimage((*reinterpret_cast< QImage(*)>(_a[1]))); break;
        case 1: _t->display_windowStat(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Facedetection::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Facedetection::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_Facedetection,
      qt_meta_data_Facedetection, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Facedetection::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Facedetection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Facedetection::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Facedetection))
        return static_cast<void*>(const_cast< Facedetection*>(this));
    return QThread::qt_metacast(_clname);
}

int Facedetection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void Facedetection::envoimage(QImage _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Facedetection::display_windowStat()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}
QT_END_MOC_NAMESPACE
