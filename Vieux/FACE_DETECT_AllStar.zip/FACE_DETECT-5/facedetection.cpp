#include "facedetection.h"


#include <QImage>
#include <omp.h>

Facedetection::Facedetection()
{
    // On initialise toutes les variables qui ne changeront pas
    // On en profite pour entrainer le model qui va nous servir à devenir les noms

    // On lance par défaut la caméra au démarage
    video = cvCaptureFromCAM( 0 );
    flip_cam = true;
    facetracked.clear();

    Stat.NbReconnaissanceOkIdOK=0;
    Stat.NbReconnaissanceOkIdKo=0;
}


void Facedetection::traite_image(Mat& frame,bool flip_cam)
{

    if(flip_cam == true)
        flip(frame,frame,1); // Evite l'effet miroir avec une caméra

    frame.copyTo( img );

    //Tracking

    int size=facetracked.size();

    for(int i=0; i<size; i++) // On parcourt tous les visags à tracker
    {

    facetracked[i].minLoc=Point();

    // Create the result matrix
    result_cols = 1 + img.cols - facetracked[i].img.cols;
    result_rows = 1 + img.rows - facetracked[i].img.rows;

    result=Mat();
    result .create( result_cols, result_rows, CV_32FC1 );

    /// Do the Matching and Normalize

    Mat gris,gris2;
    cvtColor( img, gris, CV_BGR2GRAY );
    cvtColor( facetracked[i].img, gris2, CV_BGR2GRAY );

    matchTemplate( gris , gris2, result, CV_TM_SQDIFF );

    normalize( result, result, 0, 1, NORM_MINMAX, -1, Mat() );

    /// For SQDIFF and SQDIFF_NORMED, the best matches are lower values. For all the other methods, the higher the better
    facetracked[i].matchLoc = facetracked[i].minLoc;

    /// Localizing the best match with minMaxLoc

    minMaxLoc( result, &minVal, &maxVal, &facetracked[i].minLoc, &facetracked[i].maxLoc, Mat() );
    double x= facetracked[i].minLoc.x;
    double y= facetracked[i].minLoc.y;
    rectangle(img, Rect(facetracked[i].minLoc,Point(x+facetracked[i].windowsize.width,y+facetracked[i].windowsize.height)), CV_RGB(0, 255,0), 1);
    cv::putText(img, facetracked[i].name ,facetracked[i].minLoc, cv::FONT_HERSHEY_PLAIN, 1.0, CV_RGB(0,255,0), 1);

    if(!facetracked[i].trackingup)
    {
        facetracked[i].prevLoc=Point(x,y);
        facetracked[i].trackingup=true;
    }

    double px= facetracked[i].prevLoc.x;
    double py= facetracked[i].prevLoc.y;

    if( (px-x)>60.0 || (px-x)<-60.0 || (py-y)>60 || (py-y)<-60 )
    {
        facetracked.erase(facetracked.begin()+i);
        i=facetracked.size();

    }else
    {
        facetracked[i].prevLoc=Point(x,y);
    }

    }

    emit envoimage(mat2qimage(img)); // On envoie ce signal à un slot qui va se charger d'afficher l'image

}

void Facedetection::run()
{

    detection detector(&frame,&facetracked,&muteximg,&mutexlist, &Stat, &NomInVideoTest);

    detect=&detector;
    muteximg.lock();
    mutexlist.lock();
    detector.start();

    // On récupère une première image pour rentrer dans la boucle
    facetracked.clear();
    frame = cvQueryFrame(video);

    bool lock_image=false,lock_list=false;
    while(!frame.empty()) // On continue tant que l'on est pas arriver à la fin de la vidéo
    {
        Stat.NbFrame++;


        if(lock_image)
            muteximg.lock();
        else
            lock_image=true;

        cv::resize(frame,frame,Size(width_screen,height_screen),0,0,INTER_LINEAR); // On redimensionne l'image à la taille du cadre d'affichage (Utile pour des avi de taille différente)
        muteximg.unlock();

        if(lock_list)
            mutexlist.lock();
        else
            lock_list=true;

        double t = (double)cvGetTickCount();
        traite_image(frame,flip_cam); // On détecte les visages et on gère l'aspect graphique
        t = (double)cvGetTickCount() - t;
        t = t/((double)cvGetTickFrequency()*1000);
        Stat.TempsTraitement+=t;

        mutexlist.unlock();
        frame = cvQueryFrame( video ); // Quand on arrive à la fin de la vidéo la matrice récupérée est vide
    }

     //detect->terminate();
     cvReleaseCapture(&video); // On libère le flux vidéo et le thread se termine

     if(display_stat)
     {
         cout << "test" << endl;
         Stat.TempsTraitement/=Stat.NbFrame;
         Stat.TauxDeDetection = (Stat.NbDetection/Stat.NbFrame)*100;
         Stat.TauxDeReconnaissance = (Stat.NbReconnaissanceOkIdOK/Stat.NbFrame)*100;

         cout << Stat.NbFrame << endl;
         cout << Stat.TempsTraitement << endl;
         cout << Stat.NbDetection << endl;
         cout << Stat.TauxDeDetection << endl;
         cout << Stat.NbReconnaissanceOkIdOK << endl;
         cout << Stat.NbReconnaissanceOkIdKo << endl;
         cout << Stat.TauxDeReconnaissance << endl;

         emit display_windowStat();
     }

     video = cvCaptureFromCAM( 0 );
     set_flip_cam(true);
     set_display_screen(false);

}

QImage Facedetection::mat2qimage(Mat& frame)
{
    // Seul une Qimage peut etre afficher dans la fenetre du programme
    // On convertit donc la Mat en QImage
    QImage frame_convert((uchar*)frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888);
    frame_convert = frame_convert.rgbSwapped();
    return frame_convert;
}

vector<Point> Facedetection::get_minPoint()
{
      vector<Point> localPoints;
      int size=facetracked.size();
      for(int i=0;i<size;i++)
          localPoints.push_back(facetracked[i].minLoc);
      return localPoints;
}

vector<Size> Facedetection::get_FaceWindowSize()
{
    vector<Size> localSize;
    int size=facetracked.size();
    for(int i=0;i<size;i++)
        localSize.push_back(facetracked[i].windowsize);
    return localSize;
}
